### youdao-dict

### 支持的平台
Ubuntu 14.04+
Deepin 2014.3、15-beta
Debian 8.2.0+

### dependence
    python3
    python3-pyqt5
    python3-requests
    python3-xlib
    python3-pillow
    tesseract-ocr-eng
    tesseract-ocr-chi-tra
    tesseract-ocr-chi-sim

### install
`sudo sh ./install.sh`

